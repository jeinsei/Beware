package com.yasirkula.unity;

/**
 * Created by yasirkula on 22.04.2018.
 */

public interface NativeCameraMediaReceiver
{
	void OnMediaReceived( String path );
}
