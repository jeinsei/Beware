package com.yasirkula.unity;

/**
 * Created by yasirkula on 5.03.2018.
 */

public interface NativeCameraPermissionReceiver
{
	void OnPermissionResult( int result );
}
